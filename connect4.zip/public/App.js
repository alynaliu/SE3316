// DOM Elements
// class cells but are not part of the top row
const allCells = document.querySelectorAll('.cell:not(.row-top)');
// here we have the top top row
const topCells = document.querySelectorAll('.cell.row-top');
// getting the reset and status
const resetButton = document.querySelector('.reset');
const statusSpan = document.querySelector('.status');

// columns
// array that gets the cells and puts them into an array
// building columns from bottom up
const column0 = [allCells[35], allCells[28], allCells[21], allCells[14], allCells[7], allCells[0], topCells[0]];
const column1 = [allCells[36], allCells[29], allCells[22], allCells[15], allCells[8], allCells[1], topCells[1]];
const column2 = [allCells[37], allCells[30], allCells[23], allCells[16], allCells[9], allCells[2], topCells[2]];
const column3 = [allCells[38], allCells[31], allCells[24], allCells[17], allCells[10], allCells[3], topCells[3]];
const column4 = [allCells[39], allCells[32], allCells[25], allCells[18], allCells[11], allCells[4], topCells[4]];
const column5 = [allCells[40], allCells[33], allCells[26], allCells[19], allCells[12], allCells[5], topCells[5]];
const column6 = [allCells[41], allCells[34], allCells[27], allCells[20], allCells[13], allCells[6], topCells[6]];
// array of array for columns
const columns = [column0, column1, column2, column3, column4, column5, column6];



// rows
// array that gets the cells and puts them into an array
const topRow = [topCells[0], topCells[1], topCells[2], topCells[3], topCells[4], topCells[5], topCells[6]];
const row0 = [allCells[0], allCells[1], allCells[2], allCells[3], allCells[4], allCells[5], allCells[6]];
const row1 = [allCells[7], allCells[8], allCells[9], allCells[10], allCells[11], allCells[12], allCells[13]];
const row2 = [allCells[14], allCells[15], allCells[16], allCells[17], allCells[18], allCells[19], allCells[20]];
const row3 = [allCells[21], allCells[22], allCells[23], allCells[24], allCells[25], allCells[26], allCells[27]];
const row4 = [allCells[28], allCells[29], allCells[30], allCells[31], allCells[32], allCells[33], allCells[34]];
const row5 = [allCells[35], allCells[36], allCells[37], allCells[38], allCells[39], allCells[40], allCells[41]];
// creating array of arrays of rows
const rows = [row0, row1, row2, row3, row4, row5, topRow];


// declaring variables
let gameLive = true;
let yellowNext = true; // to determine who goes first, yellow always goes first-game rules


// functions
const getClassListArray = (cell) => {
    const classList = cell.classList;

    // making the classList into an array
    // can do Array.from(classList)
    return [...classList];
};

// getting the cell location
const getCellLoc = (cell) => {
    const classList = getClassListArray(cell);

    // need to get row and column class
    // iterating over each element in the array to find the row/column index
    const rowClass = classList.find(className => className.includes('row'));
    const colClass = classList.find(className => className.includes('col'));
    // creating array for the row and col index
    const rowIndex = rowClass[4];
    const colIndex = colClass[4];
    // need to convert these into numbers now 
    const rowNum = parseInt(rowIndex, 10);
    const colNum = parseInt(colIndex, 10);

    return [rowNum, colNum];
};

// to find first open available cell
const getFirstOpenCellColumn = (colIndex) => {
    const column = columns[colIndex];
    // look through column array and give us first open col index in the array
    // get last index of the element --don't want to include the 6th element
    // slice and not include the last element which is 6
    const columnWithoutTop = column.slice(0, 6);

    // starting from bottom to check if red or yellow class
    for (const cell of columnWithoutTop) {
        // loop through each cell in the array columnWithoutTop
        const classList = getClassListArray(cell);
        // want to see if yellow or red class
        // this means the column is empty, dealing w first open cell
        if(!classList.includes('yellow') && !classList.includes('red')) {
            return cell;
        }
    }
    return null;
}

// clearing the color from the top hover
const clearColorFromTop = (colIndex) => {
    // getting topCell index
    const topCell = topCells[colIndex];
    // just remove checker regardless which color exists
    topCell.classList.remove('yellow');
    topCell.classList.remove('red');
}

// getting the color of the cell
const getColorOfCell = (cell) => {
    // getting classList for the cell
    const classList = getClassListArray(cell);
    // returning the color of the cell
    if (classList.includes('yellow')) return 'yellow';
    if (classList.includes('red')) return 'red';
    // if no color return null
    return null;
}

// checking if there is a winning combo
const checkWinningCells = (cells) => {
    // if the cell length is less than 4, don't do anything
    if (cells.length < 4) return false;
    
    // if it's greater than 4, then game over
    // if (cells.length>=4) {
    
    gameLive = false;
    for (const cell of cells) {
       cell.classList.add('win');
    }


    // updating status span depending on who won
    statusSpan.textContent = `Game over! ${yellowNext ? 'yellow' : 'red'} has won!`
    // need to return a bool to check if game should continue
    return true;
}




// checking status of the game
const checkStatusOfGame = (cell) => {
    // first getting color of the cell
    const color = getColorOfCell(cell);
    // if no color return/don't do anything
    if (!color) return;
    // need to get cell location first if there is color
    const [rowIndex, colIndex] = getCellLoc(cell);


    // if there is a color: check horizontally first starting on the LHS then RHS
    let winningCells = [cell];
    // row index for row checking and for columns too
    // bc cell being placed in will be part of the winning formula
    let rowToCheck = rowIndex;
    // bc starting from LHS the colIndex is -1
    let colToCheck = colIndex - 1;

    // do while loop to check LHS first
    // bc if column index is 0 no column on LHS
    while (colToCheck >=0 ) {
        const cellToCheck = rows[rowToCheck][colToCheck];
        // gettting cell associated w the two parameters^
        // now checking for color theory if in a row
        if (getColorOfCell(cellToCheck) === color) {
            // adding the color to wining cell array
            winningCells.push(cellToCheck);
            // checking the next column
            colToCheck--;
        } 
        //if cell is open or another color then break
        else {
            break;
        }
    }
    // now checking RHS horizontally
    colToCheck = colIndex + 1;
    // because last column is number six
    while (colToCheck <= 6 ) { 
        const cellToCheck = rows[rowToCheck][colToCheck];
        // gettting cell associated w the two parameters
        // now checking for color theory if in a row
        if (getColorOfCell(cellToCheck) === color) {
            // adding the color to wining cell array
            winningCells.push(cellToCheck);
            colToCheck++;
        } 
        //if cell is open or another color then break
        else {
            break;
        }
    }

    // checking for the win combo to see if game should continue
    let isWinCombo = checkWinningCells(winningCells);
    if (isWinCombo) return;
    // if not win combo, continue line of code

    // checking vertically now
    // no let statements--can't declare same variable just reset them
    // if there is a color: check vertically now upwards first
    winningCells = [cell];
    rowToCheck = rowIndex - 1;
    colToCheck = colIndex;
    while (rowToCheck >= 0) {
        const cellToCheck = rows[rowToCheck][colToCheck];
        if (getColorOfCell(cellToCheck) === color) {
            // adding the color to wining cell array
            winningCells.push(cellToCheck);
            // checking the next column
            rowToCheck--;
        } 
        else {
            break;
        }
    }
    // now checking downwards
    rowToCheck = rowIndex + 1;
    while (rowToCheck <= 5 ) { // 5 rows
        const cellToCheck = rows[rowToCheck][colToCheck];
        if (getColorOfCell(cellToCheck) === color) {
            // adding the color to wining cell array
            winningCells.push(cellToCheck);
            rowToCheck++;
        } 
        else {
            break;
        }
    }
    // checking for the win combo to see if game should continue
    isWinCombo = checkWinningCells(winningCells);
    if (isWinCombo) return;

    // checking to see if game is won: if there's 4 in a row
    if (winningCells.length >= 4) {
        gameLive = false;

    }


    // checking for a tie now
    // slicing to remove top row-invisible
    const rowNoTop = rows.slice(0,6);
    // setting tie to false first
    let isTie = false;
    for (const row of rowNoTop) {
        for (const cell of row) {
            const classList = getClassListArray(cell);
            // if the top row isn't full, then continue the game
            // tie only happens if it's true
            if(!classList.includes('yellow') && !classList.includes('red')) {
                return;
            }
        }
    }

    // if never return above, then it's a tie
    gameLive = false;
    statusSpan.textContent = "Game over! Tied. Click reset to restart."
}







// event handlers
// first is to handle the hover fn
const handleCellMouseOver = (e) => {
    // if the game isn't live, don't play
    if (!gameLive) return;
    const cell = e.target

    // calling the fn and will get 2 elements: the row number and column number
    const [rowIndex, colIndex] = getCellLoc(cell);
    // destructuring the array elements in number form

    // for hovering the top cell row above the board
    const topCell = topCells[colIndex];

    // short hand notation for below--if yellowNext is true, then hover will be yellow
    // if yellowNext is not true, then the hover will be red
    topCell.classList.add(yellowNext ? 'yellow' : 'red');
    // if (yellowNext) {
    //     topCell.classList.add('yellow');
    // } else {
    //     topCell.classList.add('red');
    // }
};

// this is to handle when mouse isn't hovering anymore
const handleCellMouseOut = (e) => {
    const cell = e.target
    const [rowIndex, colIndex] = getCellLoc(cell);
    
    //clearing color:
    clearColorFromTop(colIndex);
};


// to handle when players click a column
const handleCellClick = (e) => {
    // if game isn't live, don't play - game over
    if (!gameLive) return;
    // need to find first available open cell from the bottom of the column, then fill from there
    const cell = e.target
    const [rowIndex, colIndex] = getCellLoc(cell);

    const openCell = getFirstOpenCellColumn(colIndex);

    // if no open cells --don't do anything; can assume it's full
    if (!openCell) return;


    // need to check game status now after each turn
    openCell.classList.add(yellowNext ? 'yellow' : 'red');
    // checking the status of the game by passing openCell into fn
    checkStatusOfGame(openCell);

    // now making the red turn
    yellowNext = !yellowNext;

    //making the checker at the top change color each turn
    clearColorFromTop(colIndex);
    // grabbing top cell to manually flip it if game is live
    if (gameLive) {
        const topCell = topCells[colIndex];
        topCell.classList.add(yellowNext ? 'yellow' : 'red');
    }


};





// adding event listeners to implement our functions in the game
// looping thorugh everything using the const rows
// nexted for loop to go through each row and each cell in each row
for (const row of rows) {
    for (const cell of row) {
        cell.addEventListener('mouseover', handleCellMouseOver);
        cell.addEventListener('mouseout', handleCellMouseOut);
        cell.addEventListener('click', handleCellClick);
    }
}

resetButton.addEventListener('click', () => {
    // removing all colors from each cell on the grid and resetting to neutral game
    for (const row of rows) {
        for (const cell of row) {
            cell.classList.remove('red');
            cell.classList.remove('yellow');
            cell.classList.remove('win');
        }
    }

    // resetting the game to 0, and the first turn is yellow
    gameLive = true;
    yellowNext = true;
    statusSpan.textContent = 'Play to win, connect 4 in a row to win!';
    }  
);